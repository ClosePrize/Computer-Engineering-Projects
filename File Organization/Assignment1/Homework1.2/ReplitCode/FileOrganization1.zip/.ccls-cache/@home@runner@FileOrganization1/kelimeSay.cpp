#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

int kelimeSayaci(const string &dosyaAdi) {
  ifstream dosya(dosyaAdi);
  if (!dosya.is_open()) {
    cerr << "Hata: Dosya bulunamadı." << endl;
    return 0;
  }

  string satir, kelime;
  int kelimeSayisi = 0;
  while (getline(dosya, satir)) {
    istringstream iss(satir);
    while (iss >> kelime) {
      kelimeSayisi++;
    }
  }
  dosya.close();
  return kelimeSayisi;
}

int main() {
  string dosyaAdi;
  cout << "Lutfen metin dosyasinin adini girin: ";
  getline(cin, dosyaAdi);

  int kelimeSayisi = kelimeSayaci(dosyaAdi);
  cout << "Metin dosyasindaki kelime sayisi: " << kelimeSayisi << endl;
  

  return 0;
}