// #include <fstream>
// #include <iostream>
// #include <string>
// using namespace std;

// void metniDosyayaYaz(const string &metin, const string &dosyaAdi) {
//   ofstream dosya(dosyaAdi);
//   if (dosya.is_open()) {
//     dosya << metin;
//     dosya.close();
//     cout << "Metin dosyaya yazildi." << endl;
//   } else {
//     cerr << "Dosya acilamadi." << endl;
//   }
// }

// string dosyadanMetniOku(const string &dosyaAdi) {
//   ifstream dosya(dosyaAdi);
//   string metin;
//   if (dosya.is_open()) {
//     getline(dosya, metin);
//     dosya.close();
//   } else {
//     cerr << "Dosya acilamadi." << endl;
//   }
//   return metin;
// }

// int main() {
//   string metin;
//   cout << "Lutfen bir metin girin: ";
//   getline(cin, metin);
//   string dosyaAdi = "metin.txt";

//   metniDosyayaYaz(metin, dosyaAdi);

//   string okunanMetin = dosyadanMetniOku(dosyaAdi);
//   cout << "Dosyadan okunan metin:" << endl;
//   cout << okunanMetin << endl;

//   return 0;
// }

#include <fstream>
#include <iostream>
#include <string>

void metniDosyayaYaz(const std::string &metin, const std::string &dosyaAdi) {
  std::ofstream dosya(dosyaAdi);
  if (dosya.is_open()) {
    dosya << metin;
    dosya.close();
    std::cout << "Metin dosyaya yazildi." << std::endl;
  } else {
    std::cerr << "Dosya acilamadi." << std::endl;
  }
}

std::string dosyadanMetniOku(const std::string &dosyaAdi) {
  std::ifstream dosya(dosyaAdi);
  std::string metin;
  if (dosya.is_open()) {
    std::getline(dosya, metin);
    dosya.close();
  } else {
    std::cerr << "Dosya acilamadi." << std::endl;
  }
  return metin;
}

int main() {
  std::string metin;
  std::cout << "Lutfen bir metin girin: ";
  std::getline(std::cin, metin);
  std::string dosyaAdi =
      "metin.txt"; // Dosyanin adini istediginiz gibi degistirebilirsiniz.

  metniDosyayaYaz(metin, dosyaAdi);

  std::string okunanMetin = dosyadanMetniOku(dosyaAdi);
  std::cout << "Dosyadan okunan metin:" << std::endl;
  std::cout << okunanMetin << std::endl;

  return 0;
}