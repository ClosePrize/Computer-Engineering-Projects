#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

int kelimeSayaci(const std::string& dosyaAdi) {
    std::ifstream dosya(dosyaAdi);
    if (!dosya.is_open()) {
        std::cerr << "Hata: Dosya bulunamadı." << std::endl;
        return 0;
    }

    std::string satir, kelime;
    int kelimeSayisi = 0;
    while (std::getline(dosya, satir)) {
        std::istringstream iss(satir);
        while (iss >> kelime) {
            kelimeSayisi++;
        }
    }

    dosya.close();
    return kelimeSayisi;
}

int main() {
    std::string dosyaAdi;
    std::cout << "Lutfen metin dosyasinin adini girin: ";
    std::getline(std::cin, dosyaAdi);

    int kelimeSayisi = kelimeSayaci(dosyaAdi);
    std::cout << "Metin dosyasindaki kelime sayisi: " << kelimeSayisi << std::endl;

    return 0;
}